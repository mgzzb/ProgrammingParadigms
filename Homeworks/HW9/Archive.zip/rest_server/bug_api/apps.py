from django.apps import AppConfig


class BugApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bug_api'
